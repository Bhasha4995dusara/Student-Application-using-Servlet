package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.StudentBean;
import com.dao.StudentDAO;
import com.util.ValidationUtils;


public class StudentUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		int studentId = Integer.parseInt(request.getParameter("studentId"));
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String course = request.getParameter("course");

		StudentBean student = new StudentBean();
		boolean isEmpty = false;
		
		if (ValidationUtils.isEmpty(name)) {
			request.setAttribute("name",
					"<font color=red>* NAME is Required</font>");
			isEmpty = true;
		} else {
			student.setName(name);
		}

		if (ValidationUtils.isEmpty(email)) {
			request.setAttribute("email",
					"<font color=red>* E-MAIL is Required</font>");
			isEmpty = true;
		} else {
			student.setEmail(email);
		}

		if(isEmpty){
			request.getRequestDispatcher("student.jsp").forward(request, response);
		}else{
			
			student.setStudentId(studentId);
			student.setMobile(mobile);
			student.setCourse(course);
			
			if(new StudentDAO().update(student)){
				System.out.println("Student Updated............");
				response.sendRedirect("studentList");
			}else{
				System.out.println("Student Updation Failed............");
				response.sendRedirect("studentList");
			}
			
		}
		
	}
	
}
