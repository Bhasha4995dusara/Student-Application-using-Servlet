package com.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.StudentBean;
import com.dao.StudentDAO;


public class StudentEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String studentId = request.getParameter("studentId");
		
		StudentBean student = new StudentDAO().getStudentByPK(studentId);
		
		if(student!=null){
			request.setAttribute("student", student);
			request.getRequestDispatcher("studentEdit.jsp").forward(request, response);
			
		}
	}

}
