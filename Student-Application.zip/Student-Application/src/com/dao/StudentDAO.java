package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.StudentBean;
import com.util.DatabaseConnectionUtils;


public class StudentDAO {

	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean insert(StudentBean student){
		boolean result = false;
		conn = DatabaseConnectionUtils.getDBCommection();
		
		if(conn!=null){
			String insertSQL ="INSERT INTO STUDENT(name,email,mobile,course) values(?,?,?,?)";
			try {
				pstmt = conn.prepareStatement(insertSQL);
				
				pstmt.setString(1,student.getName());
				pstmt.setString(2,student.getEmail());
				pstmt.setString(3,student.getMobile());
				pstmt.setString(4,student.getCourse());
				
				int rowsAffected = pstmt.executeUpdate();
				
				if(rowsAffected>0){
					System.out.println("Data Inserted Successful......");
					result = true;
				}else{
					System.out.println("Insertion Failed......");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return result;
	
	}

public List<StudentBean> select(){
		
		conn = DatabaseConnectionUtils.getDBCommection();
		List<StudentBean> listOfStudents = new ArrayList<StudentBean>();
		if(conn!=null){
			try {
				String selectSQL = "SELECT * FROM STUDENT";
				
				pstmt = conn.prepareStatement(selectSQL);
				
				rs = pstmt.executeQuery();
				
				StudentBean student = null;
				
				while(rs.next()){
					student = new StudentBean();

					student.setStudentId(rs.getInt("STUDENTID"));
					student.setName(rs.getString("NAME"));
					student.setCourse(rs.getString("COURSE"));
					student.setEmail(rs.getString("EMAIL"));
					student.setMobile(rs.getString("MOBILE"));
					
					listOfStudents.add(student);
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("List Size : "+listOfStudents.size());
		return listOfStudents;
	}
	
public StudentBean getStudentByPK(String studentId){
	StudentBean student =  new StudentBean();
	
	conn = DatabaseConnectionUtils.getDBCommection();
	
	if(conn!=null){
		try {
			String selectSQL = "SELECT * FROM STUDENT WHERE STUDENTID = ?";
			
			pstmt = conn.prepareStatement(selectSQL);
			
			pstmt.setString(1, studentId);
			
			rs = pstmt.executeQuery();
			
			
			
			while(rs.next()){
				

				student.setStudentId(rs.getInt("STUDENTID"));
				student.setName(rs.getString("NAME"));
				student.setCourse(rs.getString("COURSE"));
				student.setEmail(rs.getString("EMAIL"));
				student.setMobile(rs.getString("MOBILE"));
				
	
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	return student;
}

	public boolean update(StudentBean student){
		boolean result = false;
		conn = DatabaseConnectionUtils.getDBCommection();
		
		if(conn!=null){
			String updateSQL ="UPDATE STUDENT SET name=?,EMAIL = ?,COURSE = ?,mobile=? WHERE STUDENTID = ?";
			try {
				pstmt = conn.prepareStatement(updateSQL );
				
				pstmt.setString(1,student.getName());
				pstmt.setString(2,student.getEmail());
				pstmt.setString(3,student.getCourse());
				pstmt.setString(4,student.getMobile());
				pstmt.setInt(5, student.getStudentId());
				
				int rowsAffected = pstmt.executeUpdate();
				
				if(rowsAffected>0){
					result = true;
					System.out.println("Update Successful......");
				}else{
					System.out.println("Updation Failed......");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return result;
	}

	public boolean delete(String studentId) {
		boolean result = false;
		
		conn = DatabaseConnectionUtils.getDBCommection();
		
		if(conn!=null){
			String deleteSQL ="DELETE FROM STUDENT WHERE STUDENTID = ?";
			try {
				pstmt = conn.prepareStatement(deleteSQL );
				
				pstmt.setString(1, studentId);
				
				int rowsAffected = pstmt.executeUpdate();
				
				if(rowsAffected>0){
					result = true;
					System.out.println("Delete Successful......");
				}else{
					System.out.println("Deletion Failed......");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		
	}
		return result;
	
	}
}
