package com.util;

public class ValidationUtils {

	public static boolean isEmpty(String param){
		boolean isEmpty = false;
		
		if(param == "" && param.trim().length() <= 0){
			isEmpty = true;
			
		}
		
		return isEmpty;
	}
	
}
