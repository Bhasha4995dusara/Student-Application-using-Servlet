package com.util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnectionUtils {

	private static String driverName = "com.mysql.jdbc.Driver";
	private static String connectionURL = "jdbc:mysql://localhost:3306/dbname";
	private static String userName = "root";
	private static String password = "root";

	public static Connection getDBCommection() {
		Connection conn = null;
		try {
			Class.forName(driverName); // Loads the Driver

			conn = DriverManager.getConnection(connectionURL,
					userName, password);

			if (conn != null) {
				System.out.println("Connected With Database.....");

			} else {
				System.out.println("Database Connection Failed.....");

			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return conn;
	}

	/*public static void main(String[] args) {
		DBConnection.getDBCommection();
	}*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
