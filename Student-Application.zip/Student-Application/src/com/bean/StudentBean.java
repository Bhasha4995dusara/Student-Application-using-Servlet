package com.bean;

import java.sql.Connection;
import java.util.List;
import java.util.ArrayList;

public class StudentBean {

	private int studentId;
	private String name;
	private String email;
	private String course;
	private String mobile;
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	/*
	 * 
	 * 
	 * 
	 * 
	 * */
	
	public void Demo(){
		Provider p1 = new Provider();
		Connection cn = p1.createConnection("localhost","3306", "stayfit_db","root", "root");
		
		List<String> l1 = new ArrayList<String>();
		l1.add("//request.getParameter(value)");
		
		CRUDOperations c1 = new CRUDOperations();
		int i = c1.createRecord(cn, "Student", l1);
		
		if(i > 0){
			System.out.println("Record Successfully Inserted...");
		}else{
			System.out.println("Error Occured....");
		}
		
		ResultSet rs = c1.getRecords(cn, "student");
		
		ResultSet rs1 = c1.getRecords(cn,"student", "sname", "bahsha");
		
		int key = c1.getMaxKey(cn, "student", "sid");
	}	
	
}
