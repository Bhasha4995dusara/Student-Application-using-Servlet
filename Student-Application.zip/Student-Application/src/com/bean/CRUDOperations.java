package com.bean;

import java.sql.*;
import java.util.*;

public class CRUDOperations {

	public int createRecord(Connection cn,String TableName,List<String> list){
		int i=0;
		
		int j=0;
		int l=list.size();
		String values="";
		for(j=0; j<l-1; j++){
			values = values + list.get(j) + ",";
		}
		values += list.get(j);
		try {
			PreparedStatement ps = cn.prepareStatement("insert into " + TableName + " values (" + values + ")");
			i=ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return i;
	}
	
	public int getMaxKey(Connection cn,String TableName,String ColumnName){
		int key=0;
		
		try{
			PreparedStatement ps = cn.prepareStatement("select max(" + ColumnName + ") from " + TableName);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				key = rs.getInt(1);
				key = key + 1;
			}else{
				key = 1;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}		
		
		return key;
	}
	
	public ResultSet getRecords(Connection cn,String TableName){
		
		ResultSet rs = null;
		
		try{
			PreparedStatement ps = cn.prepareStatement("select * from " + TableName);
			rs = ps.executeQuery();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return rs;
	}
	
	public ResultSet getRecords(Connection cn,String TableName,String ColumnName,String Condition){
		
		ResultSet rs = null;
		
		try{
			PreparedStatement ps = cn.prepareStatement("select * from " + TableName + " where " + ColumnName + "=" + Condition);
			rs = ps.executeQuery();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return rs;
	}
}