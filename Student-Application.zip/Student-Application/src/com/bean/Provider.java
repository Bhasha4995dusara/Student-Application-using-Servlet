package com.bean;

import java.sql.*;

public class Provider {

	Provider(){
	}
	
	public Connection createConnection(String host,String port,String DBName,String Username,String Password){
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + DBName,Username,Password);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
		return con;
	}	
}
